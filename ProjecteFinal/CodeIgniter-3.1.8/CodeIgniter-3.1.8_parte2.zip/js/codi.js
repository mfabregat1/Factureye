$('#logout').click(function(){
    $(location).attr('href',"<?php echo site_url('factureye/logout')?>");
});