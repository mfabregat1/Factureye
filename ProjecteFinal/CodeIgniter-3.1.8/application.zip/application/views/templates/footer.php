        <div class="navbar navbar-fixed-bottom" style="background-color:#d9d9d9; margin-top: 50px;">
            <div class="container">
              <p class="navbar-text pull-left">&copy <?php echo date('Y');?> - Marc Fabregat.</p>
           </div>
        </div>    
    </body>
</html>