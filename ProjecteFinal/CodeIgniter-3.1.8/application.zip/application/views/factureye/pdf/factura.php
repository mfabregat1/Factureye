<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>FacturEye</title>
        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/estil.css">
    </head>
    <body>
        <div id="contenidor_factura">
            <table callspacing="15" cellpadding="5" class="table">
                <tbody>
                    <tr>
                        <td style="width: 25%; color: #444444;">
                            <?php
                            if ($arrayLogo['logo'] == false){
                                $imatge = "<img src='https://vignette.wikia.nocookie.net/dragonball/images/3/32/Cruz-roja-x-mal-no-clipart_428380.jpg/revision/latest?cb=20121120163956&path-prefix=es'>";
                            }else{
                                $imatge = "<img src='".FCPATH."img\\".$arrayLogo['nom']."'>";
                            }
                            echo $imatge;
                            ?>
                        </td>
                        <td style="width: 50%; color: #34495e;font-size:12px;text-align:center">
                            <?php
                            echo "<span style='color: #34495e;font-size:14px;font-weight:bold'>".$arrayInfoEmpresa['nom_empresa']."</span><br/>";
                            echo "<b>".$arrayInfoEmpresa['direccio']."</b><br/>";
                            echo "<b>".$arrayInfoEmpresa['ciutat'].", ".$arrayInfoEmpresa['provincia'].", ".$arrayInfoEmpresa['codi_postal']."</b><br/>";
                            echo "<b>".$arrayInfoEmpresa['email']."</b><br/>";
                            echo "<b>".$arrayInfoEmpresa['telefon']."</b><br/>";
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <br/>
            <table cellpadding="5">
                <thead>
                    <tr>
                        <th>Informaci&#243; de la Factura</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td><b>Numero de Factura: </b> <?php echo htmlspecialchars($arrayInfoFactura[0]['numero_factura'],ENT_QUOTES,'UTF-8');?></td></tr>
                    <tr><td><b>Client : </b><?php echo htmlspecialchars($arrayInfoFactura[0]['nom_client'],ENT_QUOTES,'UTF-8');?></td></tr>
                    <tr><td><b>Venedor : </b><?php echo htmlspecialchars($arrayInfoFactura[0]['first_name'],ENT_QUOTES,'UTF-8')." ".htmlspecialchars($arrayInfoFactura[0]['last_name'],ENT_QUOTES,'UTF-8');?></td></tr>
                </tbody>
            </table>
            <br/>
            <table cellpadding="10">
                <thead>
                    <tr>
                        <th>Codi Producte</th>
                        <th>Nom Producte</th>
                        <th>Quantitat</th>
                        <th>Preu</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $preu_final_sense_iva = 0;
                for ($i=0; $i<count($arrayProductesFactura); $i++){ ?>
                    <tr>
                        <td><?php echo htmlspecialchars($arrayProductesFactura[$i]['codi_producte'],ENT_QUOTES,'UTF-8');?></td>
                        <td><?php echo htmlspecialchars($arrayProductesFactura[$i]['nom_producte'],ENT_QUOTES,'UTF-8');?></td>
                        <td><?php echo htmlspecialchars($arrayProductesFactura[$i]['quantitat'],ENT_QUOTES,'UTF-8');?></td>
                        <td><?php $preu_producte = $arrayProductesFactura[$i]['preu_producte'] * $arrayProductesFactura[$i]['quantitat']; $preu_final_sense_iva = $preu_final_sense_iva+$preu_producte; echo $preu_producte;?></td>
                    </tr> 

                <?php } 
                $iva = intval($arrayInfoEmpresa['impost']);
                $preu_final_amb_iva = $preu_final_sense_iva+($preu_final_sense_iva * $iva / 100);
                ?>
                    <tr>
                        <td></td><td></td>
                        <td><b>IVA : </b></td>
                        <td><b><?php echo htmlspecialchars($arrayInfoEmpresa['impost'],ENT_QUOTES,'UTF-8');?>%</b></td>
                    </tr>
                    <tr>
                        <td></td><td></td>
                        <td><b>Preu Final (SENSE IVA): </b></td>
                        <td><b><?php echo htmlspecialchars($preu_final_sense_iva,ENT_QUOTES,'UTF-8');?>&#8364;</b></td>
                    </tr>
                    <tr>
                        <td></td><td></td>
                        <td><b>Preu Final (AMB IVA): </b></td>
                        <td><b><?php echo htmlspecialchars($preu_final_amb_iva,ENT_QUOTES,'UTF-8');?>&#8364;</b></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</html>