<div id="fondo">
    <div class="panel panel-primary" id='panel_intern'>
        <div class="panel-heading">
            <h1>Clients</h1>
        </div>
        <div class="panel-body" id="panel-grocery">
            <iframe src="<?php echo site_url("factureye/grocery_clients");?>" width="100%" height="555px" style='border:none;'></iframe>
        </div>
    </div>
</div>